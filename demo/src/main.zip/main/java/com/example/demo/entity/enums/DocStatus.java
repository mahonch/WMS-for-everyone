package com.example.demo.entity.enums;

public enum DocStatus {
    DRAFT, COMMITTED
}
