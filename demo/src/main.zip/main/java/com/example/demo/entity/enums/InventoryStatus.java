package com.example.demo.entity.enums;

public enum InventoryStatus {
    OPEN, CLOSED
}
