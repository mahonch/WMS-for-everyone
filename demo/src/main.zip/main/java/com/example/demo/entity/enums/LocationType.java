package com.example.demo.entity.enums;

public enum LocationType {
    ZONE, RACK, SHELF, BIN
}
